# Rodshan – Portfolio

Personal portfolio website built with HTML, CSS and JavaScript.

**Live site:** https://YOUR-USERNAME.github.io/portfolio/

## Sections
About · Projects · Skills · Journey · Contact (GitHub, Instagram, Facebook)

## Run locally
Open `index.html` in a browser, or use the Live Server extension in VS Code.
